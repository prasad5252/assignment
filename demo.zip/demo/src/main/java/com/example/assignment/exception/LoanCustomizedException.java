package com.example.assignment.exception;

public class LoanCustomizedException extends RuntimeException{

    public LoanCustomizedException(String message) {
        super(message);
    }
}
